import snowflake.connector
import requests
import json
import time
import random
import os
from datetime import datetime

# ==========================================
# 1. CONFIGURATION ⚙️
# ==========================================

# Snowflake Credentials
SF_USER = "dbt_user"   
SF_PASSWORD = "dbt_password"   
SF_ACCOUNT = "ju10931.eu-central-2.aws"

SF_WAREHOUSE = "TOURISM_WH"
SF_DATABASE = "TOURISM_DB"
SF_SCHEMA = "RAW_DATA"

# WeatherAPI Key
WEATHER_API_KEY = "e860ba2ad884428f820204922252411"

# Update Interval (5 Minutes)
INTERVAL_SECONDS = 300 

# ==========================================
# 2. OPERATING HOURS LOGIC 🕒
# ==========================================
def is_location_open(loc_type, hour):
    """
    تحديد ما إذا كان المكان مفتوحاً بناءً على نوعه والساعة الحالية
    """
    # 1. Museums & Historical (Pyramids, Temples) -> Open 8 AM to 5 PM
    if loc_type in ["Historical", "Museum"]:
        return 8 <= hour < 17
    
    # 2. Market & Leisure (Khan El Khalili, Cairo Tower) -> Open 9 AM to 12 AM
    elif loc_type in ["Market", "Leisure"]:
        return 9 <= hour < 24
        
    # 3. Religious & Cultural -> Open 8 AM to 9 PM
    elif loc_type in ["Religious", "Cultural"]:
        return 8 <= hour < 21
        
    # 4. Nature (Reserves, Oasis) -> Open 6 AM to 6 PM (Sunlight)
    elif loc_type == "Nature":
        return 6 <= hour < 18
    
    # Default
    return 9 <= hour < 17

# ==========================================
# 3. LOCATIONS LIST (FULL 60) 📍
# ==========================================
LOCATIONS = [
    # --- Giza & Cairo ---
    {"id": "CAI_01", "name": "Pyramids of Giza", "city": "Giza", "type": "Historical", "weight": 1.0},
    {"id": "CAI_02", "name": "Great Sphinx", "city": "Giza", "type": "Historical", "weight": 1.0},
    {"id": "CAI_03", "name": "Grand Egyptian Museum (GEM)", "city": "Giza", "type": "Museum", "weight": 1.0},
    {"id": "CAI_04", "name": "Egyptian Museum (Tahrir)", "city": "Cairo", "type": "Museum", "weight": 0.9},
    {"id": "CAI_05", "name": "NMEC (Civilization Museum)", "city": "Cairo", "type": "Museum", "weight": 0.9},
    {"id": "CAI_06", "name": "Salah El-Din Citadel", "city": "Cairo", "type": "Historical", "weight": 0.8},
    {"id": "CAI_07", "name": "Khan El-Khalili", "city": "Cairo", "type": "Market", "weight": 0.95},
    {"id": "CAI_08", "name": "Al-Muizz Street", "city": "Cairo", "type": "Historical", "weight": 0.85},
    {"id": "CAI_09", "name": "Cairo Tower", "city": "Cairo", "type": "Leisure", "weight": 0.7},
    {"id": "CAI_10", "name": "Al-Azhar Park", "city": "Cairo", "type": "Leisure", "weight": 0.75},
    {"id": "CAI_11", "name": "Baron Empain Palace", "city": "Cairo", "type": "Historical", "weight": 0.65},
    {"id": "CAI_12", "name": "Coptic Museum", "city": "Cairo", "type": "Museum", "weight": 0.5},
    {"id": "CAI_13", "name": "Hanging Church", "city": "Cairo", "type": "Religious", "weight": 0.6},
    {"id": "CAI_14", "name": "Mosque of Ibn Tulun", "city": "Cairo", "type": "Religious", "weight": 0.4},
    {"id": "CAI_15", "name": "Manial Palace", "city": "Cairo", "type": "Historical", "weight": 0.45},
    {"id": "CAI_16", "name": "Abdeen Palace Museum", "city": "Cairo", "type": "Museum", "weight": 0.4},
    {"id": "CAI_17", "name": "Nilometer", "city": "Cairo", "type": "Historical", "weight": 0.2},

    # --- Luxor ---
    {"id": "LUX_01", "name": "Karnak Temple", "city": "Luxor", "type": "Historical", "weight": 0.95},
    {"id": "LUX_02", "name": "Luxor Temple", "city": "Luxor", "type": "Historical", "weight": 0.9},
    {"id": "LUX_03", "name": "Valley of the Kings", "city": "Luxor", "type": "Historical", "weight": 0.95},
    {"id": "LUX_04", "name": "Hatshepsut Temple", "city": "Luxor", "type": "Historical", "weight": 0.85},
    {"id": "LUX_05", "name": "Valley of the Queens", "city": "Luxor", "type": "Historical", "weight": 0.7},
    {"id": "LUX_06", "name": "Colossi of Memnon", "city": "Luxor", "type": "Historical", "weight": 0.6},
    {"id": "LUX_07", "name": "Luxor Museum", "city": "Luxor", "type": "Museum", "weight": 0.5},
    {"id": "LUX_08", "name": "Mummification Museum", "city": "Luxor", "type": "Museum", "weight": 0.3},
    {"id": "LUX_09", "name": "Medinet Habu", "city": "Luxor", "type": "Historical", "weight": 0.4},
    {"id": "LUX_10", "name": "Ramesseum", "city": "Luxor", "type": "Historical", "weight": 0.35},

    # --- Aswan ---
    {"id": "ASW_01", "name": "Abu Simbel Temples", "city": "Aswan", "type": "Historical", "weight": 0.9},
    {"id": "ASW_02", "name": "Philae Temple", "city": "Aswan", "type": "Historical", "weight": 0.85},
    {"id": "ASW_03", "name": "Nubian Village", "city": "Aswan", "type": "Cultural", "weight": 0.8},
    {"id": "ASW_04", "name": "Aswan High Dam", "city": "Aswan", "type": "Engineering", "weight": 0.6},
    {"id": "ASW_05", "name": "Nubian Museum", "city": "Aswan", "type": "Museum", "weight": 0.5},
    {"id": "ASW_06", "name": "Unfinished Obelisk", "city": "Aswan", "type": "Historical", "weight": 0.45},
    {"id": "ASW_07", "name": "Botanical Garden", "city": "Aswan", "type": "Nature", "weight": 0.5},
    {"id": "ASW_08", "name": "Tombs of the Nobles", "city": "Aswan", "type": "Historical", "weight": 0.3},
    {"id": "ASW_09", "name": "Kalabsha Temple", "city": "Aswan", "type": "Historical", "weight": 0.25},

    # --- Alexandria ---
    {"id": "ALX_01", "name": "Bibliotheca Alexandrina", "city": "Alexandria", "type": "Cultural", "weight": 0.85},
    {"id": "ALX_02", "name": "Qaitbay Citadel", "city": "Alexandria", "type": "Historical", "weight": 0.9},
    {"id": "ALX_03", "name": "Catacombs of Kom El Shoqafa", "city": "Alexandria", "type": "Historical", "weight": 0.6},
    {"id": "ALX_04", "name": "Montaza Palace Gardens", "city": "Alexandria", "type": "Leisure", "weight": 0.75},
    {"id": "ALX_05", "name": "Pompey's Pillar", "city": "Alexandria", "type": "Historical", "weight": 0.5},
    {"id": "ALX_06", "name": "Royal Jewelry Museum", "city": "Alexandria", "type": "Museum", "weight": 0.4},
    {"id": "ALX_07", "name": "Stanley Bridge", "city": "Alexandria", "type": "Leisure", "weight": 0.8},

    # --- Red Sea & Sinai ---
    {"id": "RED_01", "name": "Ras Mohammed", "city": "Sharm El Sheikh", "type": "Nature", "weight": 0.85},
    {"id": "RED_02", "name": "SOHO Square", "city": "Sharm El Sheikh", "type": "Leisure", "weight": 0.7},
    {"id": "RED_03", "name": "Saint Catherine Monastery", "city": "Saint Catherine", "type": "Religious", "weight": 0.6},
    {"id": "RED_04", "name": "Mount Sinai", "city": "Saint Catherine", "type": "Nature", "weight": 0.55},
    {"id": "RED_05", "name": "Blue Hole", "city": "Dahab", "type": "Nature", "weight": 0.8},
    {"id": "RED_06", "name": "Giftun Island", "city": "Hurghada", "type": "Nature", "weight": 0.85},
    {"id": "RED_07", "name": "Hurghada Marina", "city": "Hurghada", "type": "Leisure", "weight": 0.75},
    {"id": "RED_08", "name": "El Gouna Downtown", "city": "El Gouna", "type": "Leisure", "weight": 0.7},
    {"id": "RED_09", "name": "Castle Zaman", "city": "Taba", "type": "Leisure", "weight": 0.3},
    {"id": "RED_10", "name": "Colored Canyon", "city": "Nuweiba", "type": "Nature", "weight": 0.4},

    # --- Oases & Others ---
    {"id": "OAS_01", "name": "Siwa Oasis", "city": "Siwa", "type": "Nature", "weight": 0.5},
    {"id": "OAS_02", "name": "Cleopatra's Spring", "city": "Siwa", "type": "Nature", "weight": 0.45},
    {"id": "OAS_03", "name": "White Desert", "city": "Farafra", "type": "Nature", "weight": 0.3},
    {"id": "OAS_04", "name": "Tuna El-Gebel", "city": "Minya", "type": "Historical", "weight": 0.2},
    {"id": "OAS_05", "name": "Beni Hasan Tombs", "city": "Minya", "type": "Historical", "weight": 0.25},
    {"id": "OAS_06", "name": "Wadi El-Hitan", "city": "Fayoum", "type": "Nature", "weight": 0.4},
    {"id": "OAS_07", "name": "Tunis Village", "city": "Fayoum", "type": "Cultural", "weight": 0.5}
]

# Unique Cities for Efficient API Calls
UNIQUE_CITIES = list(set([loc['city'] for loc in LOCATIONS]))

# ==========================================
# 4. HOLIDAYS 2025 📅
# ==========================================
HOLIDAYS_2025 = {
    "2025-01-07", "2025-01-25", "2025-03-29", "2025-03-30", "2025-03-31",
    "2025-04-21", "2025-04-25", "2025-05-01", "2025-06-05", "2025-06-06",
    "2025-06-30", "2025-07-24", "2025-10-06"
}
def check_is_holiday(date_obj):
    return 1 if date_obj.strftime("%Y-%m-%d") in HOLIDAYS_2025 else 0

# ==========================================
# 5. HELPER FUNCTIONS 🛠️
# ==========================================

def get_snowflake_connection():
    return snowflake.connector.connect(
        user=SF_USER, password=SF_PASSWORD, account=SF_ACCOUNT,
        warehouse=SF_WAREHOUSE, database=SF_DATABASE, schema=SF_SCHEMA
    )

def get_live_weather(cities):
    print("   -> Fetching LIVE Weather & AQI...")
    weather_data = {}
    for city in cities:
        try:
            url = f"http://api.weatherapi.com/v1/current.json?key={WEATHER_API_KEY}&q={city}&aqi=yes"
            res = requests.get(url)
            if res.status_code == 200:
                d = res.json()
                weather_data[city] = {
                    "temp_c": d['current']['temp_c'],
                    "humidity": d['current']['humidity'],
                    "aqi": d['current']['air_quality']['us-epa-index']
                }
            else:
                weather_data[city] = {"temp_c": 25.0, "aqi": 2, "humidity": 50}
        except:
            weather_data[city] = {"temp_c": 25.0, "aqi": 2, "humidity": 50}
    return weather_data

# ==========================================
# 6. MAIN STREAMING LOOP 🔄
# ==========================================

print("==============================================")
print("   🚀 SMART TOURISM 24/7 SENSOR SIMULATION")
print("==============================================")
print(f"   Monitoring {len(LOCATIONS)} Locations.")
print(f"   Update Frequency: Every {INTERVAL_SECONDS} seconds (5 Minutes).")
print("==============================================\n")

try:
    # Ensure stage exists
    conn = get_snowflake_connection()
    conn.cursor().execute("CREATE OR REPLACE STAGE STREAMING_STAGE FILE_FORMAT = (TYPE = 'JSON' STRIP_OUTER_ARRAY = TRUE)")
    conn.close()

    while True:
        start_time = datetime.now()
        print(f"[{start_time.strftime('%H:%M:%S')}] Generating Batch...")

        # 1. Context
        live_weather = get_live_weather(UNIQUE_CITIES)
        current_hour = start_time.hour
        is_weekend = 1 if start_time.weekday() in [4, 5] else 0
        is_holiday = check_is_holiday(start_time)
        
        generated_rows = []

        for loc in LOCATIONS:
            # === LOGIC: CHECK OPENING HOURS ===
            if not is_location_open(loc['type'], current_hour):
                # If closed, send zeros (Maintenance/Security mode)
                visitors = 0
                res_usage = 0.0
                noise = 30.0 # Base ambient noise
                sat = 0.0
                alloc = "Closed"
                peak = 0
            else:
                # If open, calculate normally
                city = loc['city']
                w = live_weather.get(city)
                base = 400 * loc['weight']
                
                time_f = 1.2 if 10 <= current_hour <= 14 else (0.9 if 18 <= current_hour <= 22 else 0.3)
                w_pen = 1.0
                if w['temp_c'] > 38: w_pen = 0.5
                if w['aqi'] > 3: w_pen -= 0.2
                
                visitors = int(base * (1.4 if is_weekend else 1.0) * (1.5 if is_holiday else 1.0) * time_f * w_pen)
                visitors = max(0, visitors + random.randint(-15, 30))

                res_usage = min(visitors / (1000 * loc['weight']), 0.99) if loc['weight'] > 0 else 0
                noise = round(35 + (visitors / 20) + random.gauss(0, 1.5), 2)
                sat = round(max(1.0, 9.0 - (res_usage * 2) - (1.5 if w['temp_c'] > 35 else 0)), 2)
                alloc = "High" if res_usage > 0.8 else ("Medium" if res_usage > 0.4 else "Low")
                peak = 1 if 11 <= current_hour <= 14 and visitors > (base * 0.8) else 0

            # Prepare Record
            # Note: We send data even if closed (with 0 visitors) for system health check
            w_final = live_weather.get(loc['city'], {"temp_c": 25, "aqi": 2}) # Safety
            
            record = {
                "timestamp": start_time.strftime("%Y-%m-%d %H:%M:%S"),
                "date": start_time.strftime("%Y-%m-%d"),
                "year": start_time.year, "month": start_time.month, "day": start_time.day,
                "hour": current_hour, "minute": start_time.minute,
                "location_id": loc['id'], "location_name": loc['name'],
                "location_type": loc['type'], "city": loc['city'],
                "visitor_count": visitors, "resource_usage": round(res_usage, 3),
                "noise_level_db": noise, "temperature_c": w_final['temp_c'],
                "air_quality_index": w_final['aqi'],
                "satisfaction_score": sat, "peak_flag": peak,
                "is_weekend": is_weekend, "is_holiday": is_holiday,
                "resource_allocation": alloc, "is_real_weather": 1
            }
            generated_rows.append(record)

        # 2. Save & Upload
        filename = f"stream_{int(time.time())}.json"
        with open(filename, 'w') as f: json.dump(generated_rows, f)
        
        try:
            conn = get_snowflake_connection()
            cur = conn.cursor()
            
            # Upload
            file_path = os.path.abspath(filename).replace('\\', '/')
            cur.execute(f"PUT 'file://{file_path}' @STREAMING_STAGE AUTO_COMPRESS=FALSE")
            
            # Copy Into (Using $1)
            copy_sql = f"""
            COPY INTO RAW_STREAMING_LOGS FROM (
                SELECT 
                    $1:timestamp::TIMESTAMP_NTZ, $1:date::DATE,
                    $1:year::INT, $1:month::INT, $1:day::INT,
                    $1:hour::INT, $1:minute::INT,
                    $1:location_id::STRING, $1:location_name::STRING,
                    $1:location_type::STRING, $1:city::STRING,
                    $1:visitor_count::INT, $1:resource_usage::FLOAT,
                    $1:noise_level_db::FLOAT, $1:temperature_c::FLOAT,
                    $1:air_quality_index::INT,
                    $1:satisfaction_score::FLOAT, $1:peak_flag::INT,
                    $1:is_weekend::INT, $1:is_holiday::INT,
                    $1:resource_allocation::STRING, $1:is_real_weather::INT,
                    CURRENT_TIMESTAMP()
                FROM @STREAMING_STAGE/{filename} (FILE_FORMAT => 'JSON_FORMAT')
            )
            """
            # Safety format create
            cur.execute("CREATE OR REPLACE FILE FORMAT JSON_FORMAT TYPE = 'JSON' STRIP_OUTER_ARRAY = TRUE")
            
            cur.execute(copy_sql)
            print(f"   ✅ Uploaded {len(generated_rows)} records (Status: {generated_rows[0]['resource_allocation']}).")
            
            conn.close()
            os.remove(filename)
            
        except Exception as e:
            print(f"   ❌ Error: {e}")

        print(f"   💤 Waiting {INTERVAL_SECONDS}s...")
        time.sleep(INTERVAL_SECONDS)

except KeyboardInterrupt:
    print("\nStopped.")
-- models/staging/stg_raw_union_visits.sql

{{ config(
    materialized='view',
    schema='STAGING'
) }}

WITH batch_history AS (
    -- 1. Batch Data (Historical CSVs/Parquet)
    SELECT
        TIMESTAMP::TIMESTAMP_NTZ AS visit_tstamp,
        DATE::DATE AS visit_date,
        LOCATION_ID,
        VISITOR_COUNT,
        RESOURCE_USAGE::FLOAT AS resource_usage,
        NOISE_LEVEL_DB::FLOAT AS noise_level_db,
        TEMPERATURE_C::FLOAT AS temperature_c,
        NULL::INT AS air_quality_index, -- AQI was not in historical batch data
        SATISFACTION_SCORE::FLOAT AS satisfaction_score,
        PEAK_FLAG::BOOLEAN AS is_peak,
        IS_WEEKEND::BOOLEAN AS is_weekend,
        IS_HOLIDAY::BOOLEAN AS is_holiday,
        RESOURCE_ALLOCATION AS resource_allocation_class,
        'BATCH' AS data_source,
        NULL::TIMESTAMP_NTZ AS ingestion_time 
    FROM {{ source('tourism_db_raw', 'RAW_BATCH_HISTORY') }}
),

streaming_logs AS (
    -- 2. Streaming Data (Live Python Ingestion)
    SELECT
        TIMESTAMP::TIMESTAMP_NTZ AS visit_tstamp,
        DATE::DATE AS visit_date,
        LOCATION_ID,
        VISITOR_COUNT,
        RESOURCE_USAGE::FLOAT AS resource_usage,
        NOISE_LEVEL_DB::FLOAT AS noise_level_db,
        TEMPERATURE_C::FLOAT AS temperature_c,
        AIR_QUALITY_INDEX::INT AS air_quality_index, -- Data exists in streaming
        SATISFACTION_SCORE::FLOAT AS satisfaction_score,
        PEAK_FLAG::BOOLEAN AS is_peak,
        IS_WEEKEND::BOOLEAN AS is_weekend,
        IS_HOLIDAY::BOOLEAN AS is_holiday,
        RESOURCE_ALLOCATION AS resource_allocation_class,
        'STREAM' AS data_source,
        INGESTION_TIME AS ingestion_time
    FROM {{ source('tourism_db_raw', 'RAW_STREAMING_LOGS') }}
),

combined_data AS (
    -- 3. Union All (Final combined raw data)
    SELECT * FROM batch_history
    UNION ALL
    SELECT * FROM streaming_logs
)

-- 4. Final Output: Filter Zeros and select all columns
SELECT 
    * FROM combined_data
WHERE visitor_count > 0

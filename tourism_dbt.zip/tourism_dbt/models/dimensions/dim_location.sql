-- models/dimensions/dim_location.sql

{{ config(
    materialized='table',
    schema='ANALYTICS',
    unique_key='location_id'
) }}

SELECT
    ROW_NUMBER() OVER (ORDER BY ID) AS location_key, 
    ID AS location_id,
    NAME AS location_name,
    CITY AS city,
    TYPE AS location_type,
    WEIGHT::FLOAT AS base_popularity_weight,
    LATITUDE AS latitude, 
    LONGITUDE AS longitude,
    OPENING_HOUR AS opening_hour,
    CLOSING_HOUR AS closing_hour

FROM {{ source('tourism_db_raw', 'RAW_LOCATIONS_REF') }}
WHERE ID IS NOT NULL

-- models/dimensions/dim_date.sql
-- Description: Creates a standardized calendar table (Date Dimension)
-- It joins all calendar days with the RAW_HOLIDAYS_REF table.

{{ config(
    materialized='table',
    schema='ANALYTICS',
    unique_key='date_key'
) }}

WITH date_spine AS (
    -- Generates all days from 2020 until the end of 2026 (7 years)
    SELECT
        DATEADD(day, seq4(), '2020-01-01') AS full_date
    FROM TABLE(GENERATOR(rowcount => 2557)) 
),

final_dates AS (
    SELECT
        TO_NUMBER(TO_CHAR(d.full_date, 'YYYYMMDD')) AS date_key,
        d.full_date AS full_date,
        YEAR(d.full_date) AS year,
        MONTH(d.full_date) AS month,
        DAYOFMONTH(d.full_date) AS day_of_month,
        DAYOFWEEKISO(d.full_date) AS day_of_week, 

        -- Holiday and Weekend Logic (Using the correct column names from RAW_HOLIDAYS_REF)
        CASE WHEN h.Date IS NOT NULL THEN TRUE ELSE FALSE END AS is_holiday,
        CASE WHEN h.Type LIKE '%National Holiday%' THEN TRUE ELSE FALSE END AS is_national_holiday,
        CASE WHEN DAYOFWEEKISO(d.full_date) IN (5, 6) THEN TRUE ELSE FALSE END AS is_weekend_friday_sat,

        -- Determine Seasonality 
        CASE
            WHEN MONTH(d.full_date) IN (12, 1, 2) THEN 'Winter'
            WHEN MONTH(d.full_date) IN (3, 4, 5) THEN 'Spring'
            WHEN MONTH(d.full_date) IN (6, 7, 8) THEN 'Summer'
            ELSE 'Autumn'
        END AS season
        
    FROM date_spine AS d
    -- Join with the RAW_HOLIDAYS_REF table
    LEFT JOIN {{ source('tourism_db_raw', 'RAW_HOLIDAYS_REF') }} AS h
        -- 💡 CORRECTION: Joining on the 'Date' column, not 'holiday_date'
        ON d.full_date = h.Date
    
    -- Ensure dates are not too far into the future
    WHERE d.full_date <= '2026-01-01'
)

SELECT * FROM final_dates

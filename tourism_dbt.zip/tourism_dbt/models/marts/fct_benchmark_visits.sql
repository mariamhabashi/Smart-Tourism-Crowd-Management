-- models/marts/fct_benchmark_visits.sql

{{ config(
    materialized='incremental',
    unique_key=['visit_tstamp', 'location_id'],
    schema='ANALYTICS'
) }}

WITH source_data AS (
    -- 1. Read from the primary Fact Table (fct_visits)
    SELECT
        visit_tstamp,
        location_id,
        visitor_count,
        resource_usage
    FROM {{ ref('fct_visits') }}

    -- CRITICAL FIX 1: Filter out all zero visitor counts BEFORE baseline calculation
    WHERE visitor_count > 0 
    
    {% if is_incremental() %}
    -- Filter 2: Process only new data since the last successful run
    AND visit_tstamp > (SELECT MAX(visit_tstamp) FROM {{ this }})
    {% endif %}
),

baseline_calculation AS (
    SELECT
        *,
        -- 2. Calculate the 3-Day Rolling Average Baseline (864 rows = 3 days * 288 readings/day)
        -- This determines the expected occupancy.
        AVG(visitor_count) OVER (
            PARTITION BY location_id
            ORDER BY visit_tstamp
            ROWS BETWEEN 864 PRECEDING AND 1 PRECEDING 
        ) AS visitor_3d_baseline
    FROM source_data
),

final_mart AS (
    SELECT
        t1.visit_tstamp,
        t1.location_id,
        t1.visitor_count,
        t1.visitor_3d_baseline,
        
        -- 3. Calculate Variance (Visitor_Variance): Current Occupancy vs. Expected Baseline
        (t1.visitor_count - t1.visitor_3d_baseline) / NULLIF(t1.visitor_3d_baseline, 0) AS visitor_variance,
        
        -- 4. Operational Alert Flag (Flag if current load exceeds baseline by 30%)
        CASE
            WHEN t1.visitor_count > t1.visitor_3d_baseline AND ((t1.visitor_count - t1.visitor_3d_baseline) / NULLIF(t1.visitor_3d_baseline, 0)) > 0.3 THEN 1
            ELSE 0
        END AS operational_alert_flag
    
    FROM baseline_calculation AS t1
    -- Ensures we only keep rows where a baseline could be calculated (removes the initial cold start NULLs)
    WHERE t1.visitor_3d_baseline IS NOT NULL
)

SELECT * FROM final_mart

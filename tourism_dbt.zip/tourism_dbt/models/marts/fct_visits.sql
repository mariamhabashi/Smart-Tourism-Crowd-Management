-- models/marts/fct_visits.sql

{{ config(
    materialized='incremental',
    unique_key=['visit_tstamp', 'location_id'],
    schema='ANALYTICS'
) }}

WITH unioned_visits AS (
    -- 1. Source: The union of Batch and Stream data
    SELECT
        visit_tstamp,
        visit_date,
        location_id,
        visitor_count,
        resource_usage,
        noise_level_db,
        temperature_c,
        satisfaction_score,
        resource_allocation_class,
        data_source

    FROM {{ ref('stg_raw_union_visits') }}
),

final_mart AS (
    SELECT
        -- Keys (Primary Join Points)
        dd.date_key AS date_key,
        dl.location_key,
        
        -- Descriptive Data (Always comes from Dimension tables for clean structure)
        uv.location_id,
        dl.location_name,
        dl.location_type,

        -- Measures
        uv.visitor_count,
        uv.resource_usage,
        uv.noise_level_db,
        uv.temperature_c,
        uv.satisfaction_score,
        
        -- Flags & Context (CRITICAL FIX: Pulling flags from DIM_DATE)
        dd.is_weekend_friday_sat AS is_weekend,       -- Pulled from DIM_DATE
        dd.is_holiday AS is_holiday,                  -- Pulled from DIM_DATE
        uv.resource_allocation_class,
        
        uv.visit_tstamp,
        uv.data_source

    FROM unioned_visits AS uv
    
    -- 1. Join to Location Dimension (for name, type, key)
    INNER JOIN {{ ref('dim_location') }} AS dl
        ON uv.location_id = dl.location_id
    
    -- 2. Join to Date Dimension (for date key and holiday flags)
    INNER JOIN {{ ref('dim_date') }} AS dd
        ON uv.visit_date = dd.full_date
)

SELECT * FROM final_mart

{% if is_incremental() %}
-- Incremental logic to process only new stream data
WHERE visit_tstamp > (SELECT MAX(visit_tstamp) FROM {{ this }})
{% endif %}

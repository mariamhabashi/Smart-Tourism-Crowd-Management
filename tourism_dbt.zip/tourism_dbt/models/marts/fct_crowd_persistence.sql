-- models/marts/fct_crowd_persistence.sql

{{ config(
    materialized='incremental',
    unique_key=['visit_tstamp', 'location_id'],
    schema='ANALYTICS'
) }}

WITH source_data AS (
    SELECT
        visit_tstamp,
        location_id,
        visitor_count,
        resource_usage,
        temperature_c,
        is_holiday
    FROM {{ ref('fct_visits') }}
    -- Filter for incremental processing
    {% if is_incremental() %}
    WHERE visit_tstamp > (SELECT MAX(visit_tstamp) FROM {{ this }})
    {% endif %}
),

congestion_metrics AS (
    SELECT
        *,
        -- AVG(RESOURCE_USAGE) over the last 6 intervals (30 minutes)
        AVG(resource_usage) OVER (
            PARTITION BY location_id
            ORDER BY visit_tstamp
            ROWS BETWEEN 6 PRECEDING AND CURRENT ROW -- 6 rows = 30 minutes
        ) AS crowd_persistence_index_cpi
        
    FROM source_data
)

SELECT
    visit_tstamp,
    location_id,
    visitor_count,
    crowd_persistence_index_cpi,
    
    -- 2. Congestion Risk Flag
    CASE
        WHEN crowd_persistence_index_cpi > 0.85 THEN TRUE -- CPI above 85% is critical
        ELSE FALSE
    END AS is_persistent_congestion,
    
    temperature_c,
    is_holiday

FROM congestion_metrics
